/** @type {import('next').NextConfig} */
const nextConfig = {
  images: { unoptimized: false },
};

export default nextConfig;
