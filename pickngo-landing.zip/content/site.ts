export const site = {
  name: "Pick’n GO",
  tagline: "Vending Machines",
  description:
    "Manejo de máquinas de vending: instalamos tu máquina en tu establecimiento y la abastecemos con productos según la línea elegida.",
  address: "Vía Ricardo J. Alfaro, Plaza León, Local 16, Betania, Panamá",
  phone: "+507 6423-3151",
  whatsapp: "+507 6854-5600",
  email: "ventas@pickngo.com",
  instagramUrl: "https://instagram.com/pickngo", // placeholder
};
