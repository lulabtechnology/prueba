import * as React from "react";
import { cn } from "@/lib/utils";

export function Input({
  className,
  ...props
}: React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <input
      className={cn(
        "h-11 w-full rounded-2xl border border-border bg-white px-4 text-sm text-ink shadow-[0_1px_0_rgba(2,6,23,0.02)] " +
          "placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-brand/30",
        className
      )}
      {...props}
    />
  );
}
